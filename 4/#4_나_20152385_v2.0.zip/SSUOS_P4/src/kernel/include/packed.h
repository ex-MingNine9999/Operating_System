#ifndef __LIB_PACKED_H
#define __LIB_PACKED_H

#define PACKED __attribute__ ((packed))

#endif 