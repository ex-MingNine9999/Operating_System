#ifndef	   __DEVICE_H__
#define	   __DEVICE_H__

extern void dev_shutdown(void);
#endif
